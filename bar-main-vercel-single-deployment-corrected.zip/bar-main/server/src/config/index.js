const path = require('path');

// Loads server/.env for local development if present.
// Vercel production values come from Project Settings → Environment Variables.
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

module.exports = {
  port: Number(process.env.PORT || 5000),
  nodeEnv: process.env.NODE_ENV || 'development',
  clientOrigin: process.env.CLIENT_ORIGIN || '*',

  // Do not fall back to localhost in production. If MONGODB_URI is absent,
  // the existing in-memory fallback is used.
  mongodbUri: process.env.MONGODB_URI || null,

  jwtSecret: process.env.JWT_SECRET || 'dev-secret-change-me',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '1d',
  jwtRefreshSecret: process.env.JWT_REFRESH_SECRET || 'dev-refresh-secret-change-me',
  jwtRefreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',

  // These values are interpreted as percentages by orderController.js.
  vatRate: parseFloat(process.env.VAT_RATE || '7.5'),
  discountApprovalThreshold: parseFloat(
    process.env.DISCOUNT_APPROVAL_THRESHOLD || '10'
  ),
};
