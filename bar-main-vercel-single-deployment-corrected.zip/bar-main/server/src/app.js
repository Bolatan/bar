const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');

const config = require('./config');
const { auth } = require('./middleware/auth');
const { notFound, errorHandler } = require('./middleware/error');
const { setMongoConnected, seedMemory } = require('./store');

const app = express();

app.disable('x-powered-by');

app.use(helmet());
app.use(compression());

app.use(
  cors({
    origin: config.clientOrigin === '*' ? true : config.clientOrigin,
    credentials: true,
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

if (config.nodeEnv !== 'test') {
  app.use(morgan('dev'));
}

let mongoConnectionPromise = null;

async function connectMongo() {
  if (!config.mongodbUri) {
    setMongoConnected(false);
    await seedMemory();
    return false;
  }

  if (mongoose.connection.readyState === 1) {
    setMongoConnected(true);
    return true;
  }

  if (mongoConnectionPromise) {
    return mongoConnectionPromise;
  }

  mongoConnectionPromise = mongoose
    .connect(config.mongodbUri, {
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000,
      maxPoolSize: 10,
      minPoolSize: 0,
      serverApi: { version: '1', strict: true, deprecationErrors: true },
    })
    .then(async () => {
      setMongoConnected(true);
      console.log('Connected to MongoDB');
      return true;
    })
    .catch(async (err) => {
      setMongoConnected(false);
      console.warn('MongoDB unavailable — running in in-memory mode.');
      console.warn(`  ${err.message}`);
      await seedMemory();
      return false;
    })
    .finally(() => {
      mongoConnectionPromise = null;
    });

  return mongoConnectionPromise;
}

// In Vercel's serverless environment, establish/reuse the MongoDB connection
// before handling an API request. The promise/cache survives warm invocations.
app.use(async (_req, _res, next) => {
  try {
    await connectMongo();
    next();
  } catch (err) {
    next(err);
  }
});

app.use('/api/auth', auth, require('./routes/auth'));
app.use('/api/users', auth, require('./routes/users'));
app.use('/api/products', auth, require('./routes/products'));
app.use('/api/suppliers', auth, require('./routes/suppliers'));
app.use('/api/stock-movements', auth, require('./routes/stock'));
app.use('/api/orders', auth, require('./routes/orders'));
app.use('/api/shifts', auth, require('./routes/shifts'));
app.use('/api/reports', auth, require('./routes/reports'));

app.get('/api/health', (_req, res) =>
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    mongo: mongoose.connection.readyState === 1,
  })
);

app.use(notFound);
app.use(errorHandler);

module.exports = { app, connectMongo };
